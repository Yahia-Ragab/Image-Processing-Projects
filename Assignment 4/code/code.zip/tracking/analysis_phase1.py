import _init_paths
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [8, 8]

# Now this import will work because we fixed the file it imports from
from lib.test.analysis.plot_results import plot_results, print_results
from lib.test.evaluation import get_dataset, trackerlist
from lib.test.evaluation.environment import env_settings

trackers = []
dataset_name = 'lasot'
tracker_name = 'seqtrack'
parameter_name = 'seqtrack_b256'

print(f"Analyzing results for {tracker_name} / {parameter_name} on {dataset_name}")
print("Loading results for selected GOOD epochs...")

# --- UPDATED LOOP: Explicitly list good epochs ---
# Add any other epochs you know are good (e.g., 5, 6, 7, 8, 9, 10) to this list.
# Epoch 2 is skipped here as an example of a corrupted one.
good_epochs = [1, 3, 4, 5, 6, 7, 8, 9, 10]

for i in good_epochs:
    run_id = i
    display_name = f'Epoch {i}'

    try:
        trackers.extend(trackerlist(name=tracker_name,
                                    parameter_name=parameter_name,
                                    dataset_name=dataset_name,
                                    run_ids=run_id,
                                    display_name=display_name))
    except Exception as e:
        print(f"Warning: Could not load Epoch {i}, skipping. Error: {e}")

dataset = get_dataset(dataset_name)

print("\n--- Evaluation Results (Phase 1) ---")
print(f"Dataset: {dataset_name} (8 target sequences)")
print("-----------------------------------------------------------------")

# This will print the table to your console (for your Table 2)
print_results(trackers, dataset, dataset_name, merge_results=False,
              plot_types=('success', 'prec', 'norm_prec'), force_evaluation=True)

# This will save the graphs as image files (e.g., lasot_success_plot.pdf)
plot_results(trackers, dataset, dataset_name, merge_results=False,
             plot_types=('success', 'prec', 'norm_prec'), skip_missing_seq=False,
             force_evaluation=True, plot_bin_gap=0.05)

print(f"\nFinished analysis. Table is above, and plot images are saved in the 'tracking/' folder.")
