import os
import numpy as np

base_dir = "./"   # change if you run from another path

print(f"{'Checkpoint':<20} {'Avg ms/frame':<20} {'FPS':<10}")
print("-" * 55)

for folder in sorted(os.listdir(base_dir)):
    if folder.startswith("seqtrack_b256_") and os.path.isdir(os.path.join(base_dir, folder)):
        lasot_folder = os.path.join(base_dir, folder, "lasot")
        if not os.path.exists(lasot_folder):
            continue

        times = []

        for file in os.listdir(lasot_folder):
            if file.endswith("_time.txt"):
                with open(os.path.join(lasot_folder, file), "r") as f:
                    # Convert each line to float and add to list
                    values = [float(x.strip()) for x in f.readlines() if x.strip()]
                    times.extend(values)

        if len(times) == 0:
            continue

        times = np.array(times)
        avg_time = times.mean() * 1000  # convert to ms/frame
        fps = 1000 / avg_time           # FPS = 1/(avg_time_seconds)

        print(f"{folder:<20} {avg_time:<20.4f} {fps:<10.2f}")
