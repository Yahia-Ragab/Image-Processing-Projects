import _init_paths
import matplotlib.pyplot as plt
plt.rcParams['figure.figsize'] = [8, 8]

from lib.test.analysis.plot_results import plot_results, print_results
from lib.test.evaluation import get_dataset, trackerlist

# --- Configuration ---
DATASET_NAME = 'lasot'
TRACKER_NAME = 'seqtrack'
PARAM_NAME = 'seqtrack_b256'
# AVAILABLE EPOCHS in your phase2 folder
AVAILABLE_EPOCHS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# ---------------------

print(f"Starting Analysis for {TRACKER_NAME}/{PARAM_NAME} on {DATASET_NAME}")
print(f"Loading results for available Epochs: {AVAILABLE_EPOCHS}")

trackers = []
for i in AVAILABLE_EPOCHS:
    run_id = i
    display_name = f'Epoch {i}'
    try:
        # --- FIX IS HERE: used PARAM_NAME instead of parameter_name ---
        trackers.extend(trackerlist(name=TRACKER_NAME,
                                    parameter_name=PARAM_NAME,
                                    dataset_name=DATASET_NAME,
                                    run_ids=run_id,
                                    display_name=display_name))
    except Exception as e:
        print(f"Warning: Could not load Epoch {i}: {e}")

dataset = get_dataset(DATASET_NAME)

print("\n--- Evaluation Results (Epochs 1-10) ---")
print_results(trackers, dataset, DATASET_NAME, merge_results=False,
              plot_types=('success', 'prec', 'norm_prec'), force_evaluation=True)

plot_results(trackers, dataset, DATASET_NAME, merge_results=False,
             plot_types=('success', 'prec', 'norm_prec'), skip_missing_seq=False,
             force_evaluation=True, plot_bin_gap=0.05)

print("\nAnalysis Complete! Plots saved in 'tracking/' folder.")
