vot evaluate --workspace . seqtrack_l384_ar



