from .resnet import resnet18, resnet50, resnet_baby
from .resnet18_vggm import resnet18_vggmconv1
