from .atom import ATOM

def get_tracker_class():
    return ATOM