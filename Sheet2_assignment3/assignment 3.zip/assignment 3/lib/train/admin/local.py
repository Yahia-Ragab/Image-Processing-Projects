class EnvironmentSettings:
    def __init__(self):
        # Base workspace directories
        self.workspace_dir = '/home/yahia/VideoX/SeqTrack'     # project root
        self.tensorboard_dir = '/home/yahia/VideoX/SeqTrack/tensorboard'
        self.pretrained_networks = '/home/yahia/VideoX/SeqTrack/checkpoints'

        # Dataset paths
        self.lasot_dir = '/home/yahia/VideoX/SeqTrack/data/LaSOT/'
        self.lasot_lmdb_dir = ''
        self.got10k_dir = ''
        self.got10k_lmdb_dir = ''
        self.trackingnet_dir = ''
        self.trackingnet_lmdb_dir = ''
        self.coco_dir = ''
        self.coco_lmdb_dir = ''
        self.imagenet1k_dir = ''
        self.imagenet22k_dir = ''
        self.lvis_dir = ''
        self.sbd_dir = ''
        self.imagenet_dir = ''
        self.imagenet_lmdb_dir = ''
        self.imagenetdet_dir = ''
        self.ecssd_dir = ''
        self.hkuis_dir = ''
        self.msra10k_dir = ''
        self.davis_dir = ''
        self.youtubevos_dir = ''
